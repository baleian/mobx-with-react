import { Module } from "ag-grid-community";
export declare const ChartsModule: Module;
