
Support and Maintenance document is now merged into the licence document. Please see the licence.
